# This file needs to exist for Django to recognize this as a Django App
